# Universal Builder OS

A modular, extensible, operator-grade builder framework that lets you generate:
- automations
- workflows
- scripts
- content engines
- scrapers
- templates
- full projects

This repo contains:
- A master builder prompt
- A module library
- A template library
- Example outputs

## How to Use

1. Open `BUILDER_PROMPT.md`
2. Copy the entire prompt
3. Paste it into your AI model (ChatGPT, Claude, VS Code GPT, GitHub Copilot Chat)
4. Say: “Load the modules and wait for my build request.”

## Add New Modules
Create a new file in `/modules` and the builder will automatically use it.

## Add New Templates
Add a file to `/templates` and reference it in your build requests.

## Example Commands
- “Build me a scraper that collects Instagram bios.”
- “Generate a Make.com-style automation flow for client onboarding.”
- “Create a content engine that turns YouTube transcripts into blog posts.”
- “Add this as a module.”

## License
MIT