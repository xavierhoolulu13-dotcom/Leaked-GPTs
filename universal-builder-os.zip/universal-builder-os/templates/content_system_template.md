# Content System Template

Inputs:
- Source
- Format
- Tone

Outputs:
- Draft
- Final version
- Optional social snippets