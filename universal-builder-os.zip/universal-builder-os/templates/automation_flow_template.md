# Automation Flow Template

- Flow Name:
- Trigger:
- Steps:
- Logic:
- Output:
- Notes: