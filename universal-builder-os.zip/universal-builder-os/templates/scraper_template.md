# Scraper Template

- Target site:
- Data to extract:
- Method:
- Output format: