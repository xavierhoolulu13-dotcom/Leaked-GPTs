# Workflow Template

- Goal:
- Inputs:
- Steps:
- Tools:
- Output: