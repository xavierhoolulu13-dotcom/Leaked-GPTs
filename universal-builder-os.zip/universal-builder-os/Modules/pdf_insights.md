# PDF Insights Module

Capabilities:
- Extract text from PDF
- Summarize
- Generate key points
- Generate action items

Constraints:
- Local extraction only