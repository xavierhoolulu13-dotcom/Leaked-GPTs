# Automation Flow Builder Module

Capabilities:
- Convert plain language into structured automation flows
- Break into steps
- Generate logic for each step
- Output JSON blueprint
- Output SOP version
- Output visual-style descriptionj