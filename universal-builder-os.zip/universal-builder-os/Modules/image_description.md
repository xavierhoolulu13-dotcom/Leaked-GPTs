# Image Description Module

Capabilities:
- Template-based product descriptions
- Optional user-provided context

Constraints:
- No actual image recognition unless model supports it