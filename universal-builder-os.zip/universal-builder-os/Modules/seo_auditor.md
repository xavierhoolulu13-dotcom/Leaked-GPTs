# SEO Auditor Module

Capabilities:
- Fetch HTML
- Analyze title, meta description, H1/H2
- Word count
- Readability
- Recommendations