# Code Reviewer Module

Capabilities:
- Static code analysis
- Bug explanation
- Improvement suggestions

Constraints:
- No execution