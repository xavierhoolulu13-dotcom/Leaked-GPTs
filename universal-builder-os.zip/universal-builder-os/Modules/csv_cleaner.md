# CSV Cleaner Module

Capabilities:
- Clean column names
- Detect missing values
- Generate basic stats
- Output cleaned CSV