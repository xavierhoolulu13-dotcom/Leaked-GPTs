# Example Scraper

Target: Instagram bios
Output: CSV of usernames + bios