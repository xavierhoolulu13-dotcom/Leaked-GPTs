# Example Content Engine

Input: YouTube transcript
Output: Blog post + social snippets