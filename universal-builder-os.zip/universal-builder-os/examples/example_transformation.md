# Example Transformation

Input: Raw text
Output: Summarized version