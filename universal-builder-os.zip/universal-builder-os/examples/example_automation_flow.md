# Example Automation Flow

Flow: Client Onboarding
Trigger: New client signs contract
Steps:
1. Create folder
2. Send welcome email
3. Assign tasks
4. Schedule kickoff call